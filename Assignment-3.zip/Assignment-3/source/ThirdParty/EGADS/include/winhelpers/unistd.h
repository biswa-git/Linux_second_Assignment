#ifndef __UNISTD_H__
#define __UNISTD_H__

#define usleep(x) Sleep(x/1000)

#endif
