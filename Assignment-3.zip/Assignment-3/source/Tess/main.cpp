#include <egads.h>
#include <math.h>
#include <fstream>
#include <iostream>
#include<string>
#include<vector>
#ifdef WIN32
#define snprintf _snprintf
#endif

//----------------------------------------------------------------
// Class Vertex: stores coordinate
//----------------------------------------------------------------
class Vertex
{
public:
	double x,y,z;
	void Assign(const double& x, const double& y, const double& z)
	{
		this->x = x;
		this->y = y;
		this->z = z;
	}
};

//----------------------------------------------------------------
// Class Connectivity: stores vertex ids of tiangle
//----------------------------------------------------------------
class Connectivity
{
public:
	int id_1, id_2, id_3;
	void Assign(const int& id_1, const int& id_2, const int& id_3)
	{
		this->id_1 = id_1;
		this->id_2 = id_2;
		this->id_3 = id_3;
	}
};
class  Vector:public Vertex
{
public:
	Vector(const double& x, const double& y, const double& z) 
	{
		this->x = x;
		this->y = y;
		this->z = z;
	}
};


Vector GetNormalUnit(Vertex* v1, Vertex* v2, Vertex* v3)
{
	auto dx1 = v2->x - v1->x;
	auto dy1 = v2->y - v1->y;
	auto dz1 = v2->z - v1->z;

	auto dx2 = v3->x - v2->x;
	auto dy2 = v3->y - v2->y;
	auto dz2 = v3->z - v2->z;

	auto x = dy1 * dz2 - dy2 * dz1;
	auto y = dz1 * dx2 - dz2 * dx1;
	auto z = dx1 * dy2 - dx2 * dy1;

	auto amp = sqrt(x * x + y * y + z * z);
	x /= amp; y /= amp; z /= amp;
	Vector vec(x,y,z);
	return vec;
}

int main(int argc, char* argv[])
{
	int				i, j, k, status, oclass, mtype, nbody, nvert, ntriang, nface;
	int				plen, tlen, pty, pin, tin[3], * senses;
	const int*		ptype, * pindex, * tris, * tric;
	std::string			filename;
	double			params[3], box[6], size, verts[3];
	const double*	points, * uv;
	std::ofstream		fp;
	ego				context, model, geom, solid, * bodies, tess, * dum, * faces;

	std::vector<Vertex>       vertexList;
	std::vector<Connectivity> connectivityList;

	if ((argc != 2) && (argc != 5)) {
		std::cout<< " Usage: egads2tri Model [angle relSide relSag]\n\n";
		return 1;
	}
	
	/* initialize */
	status = EG_open(&context);
	if (status != EGADS_SUCCESS) {
		std::cout << "EG_open = " << status << std::endl;
		return 1;
	}
	status = EG_loadModel(context, 0, argv[1], &model);
	if (status != EGADS_SUCCESS) {
		std::cout << "EG_loadModel = " << status << std::endl;
		return 1;
	}
	status = EG_getBoundingBox(model, box);
	if (status != EGADS_SUCCESS) {
		std::cout << "EG_getBoundingBox = " << status << std::endl;
		return 1;
	}

	size = sqrt((box[0] - box[3]) * (box[0] - box[3]) + (box[1] - box[4]) * (box[1] - box[4]) +
		(box[2] - box[5]) * (box[2] - box[5]));

	/* get all bodies */
	status = EG_getTopology(model, &geom, &oclass, &mtype, NULL, &nbody,
		&bodies, &senses);
	if (status != EGADS_SUCCESS) {
		std::cout << "EG_getTopology = " << status << std::endl;
		return 1;
	}

//	params[0] = 0.025 * size;
//	params[1] = 0.001 * size;
//	params[2] = 15.0;

	//if (argc == 5) {
		std::cout << "reading Args" << std::endl;
		params[2] = std::atof(argv[argc - 3]);
		params[0] = std::atof(argv[argc - 2]);
		params[1] = std::atof(argv[argc - 1]);

	//}
	//---------------------------------------------------
	//optimal value for misc1.step
		//params[0] = 0.0;
		//params[1] = 0.07;
		//params[2] = 10;
		std::cout << " Using angle = " << params[2] << " relSide = " << params[0] << " relSag = " << params[1] << std::endl;
		params[0] *= size;
		params[1] *= size;
	//---------------------------------------------------

	std::cout << "Number of Bodies = " << nbody << std::endl;
	/* write out each body as a different Cart3D ASCII tri file */

	for (i = 0; i < nbody; i++) {
		solid = bodies[i];

		mtype = 0;
		EG_getTopology(bodies[i], &geom, &oclass, &mtype, NULL, &j, &dum, &senses);
		if (mtype == SHEETBODY) {
			status = EG_makeTopology(context, NULL, BODY, SOLIDBODY, NULL, j, dum,
				NULL, &solid);
			if (status == EGADS_SUCCESS) {
				std::cout << " SheetBody" << i << "promoted to SolidBody" << std::endl;
				mtype = SOLIDBODY;
			}
			else {
				std::cout << " SheetBody" << i << "promoted to SolidBody" << std::endl;
			}
		}
		if (mtype != SOLIDBODY) continue;   /* only Solid Bodies! */

		status = EG_makeTessBody(solid, params, &tess);
		if (status != EGADS_SUCCESS) {
			std::cout << "EG_makeTessBody " << i << " = " << status << std::endl;
			if (solid != bodies[i]) EG_deleteObject(solid);
			continue;
		}
		status = EG_getBodyTopos(solid, NULL, FACE, &nface, &faces);
		if (status != EGADS_SUCCESS) {
			std::cout << "EG_getBodyTopos " << i << " = " << status << std::endl;
			if (solid != bodies[i]) EG_deleteObject(solid);
			EG_deleteObject(tess);
			continue;
		}
		EG_free(faces);

		/* get counts */
		status = EG_statusTessBody(tess, &geom, &j, &nvert);
		std::cout << "statusTessBody = " << status << " " << j << "npts = " << status << std::endl;
		if (status != EGADS_SUCCESS) continue;
		ntriang = 0;
		for (j = 0; j < nface; j++) {
			status = EG_getTessFace(tess, j + 1, &plen, &points, &uv, &ptype, &pindex,
				&tlen, &tris, &tric);
			if (status != EGADS_SUCCESS) {
				std::cout << "Error: EG_getTessFace " << j + 1 << "/" << nvert << " = " << status << std::endl;
				continue;
			}
			ntriang += tlen;
		}

		/* write it out */
		vertexList.resize(nvert);
		connectivityList.resize(ntriang);

		
/*
		if (!fp.is_open()) {
			std::cout << "Can not Open file " << filename << "! NO FILE WRITTEN" << std::endl;
			if (solid != bodies[i]) EG_deleteObject(solid);
			continue;
		}
*/

		/* ...vertList     */
		for (j = 0; j < nvert; j++) {
			status = EG_getGlobal(tess, j + 1, &pty, &pin, verts);
			if (status != EGADS_SUCCESS) std::cout << " Error: EG_getGlobal " << j + 1 << "/" << nvert << " = " << status << std::endl;
			vertexList[j].Assign(verts[0], verts[1], verts[2]);
		}
		/* ...Connectivity */
		size_t connectivityListId = 0;
		for (j = 0; j < nface; j++) {
			status = EG_getTessFace(tess, j + 1, &plen, &points, &uv, &ptype, &pindex,
				&tlen, &tris, &tric);
			if (status != EGADS_SUCCESS) continue;
			for (k = 0; k < tlen; k++) {
				status = EG_localToGlobal(tess, j + 1, tris[3 * k], &tin[0]);
				if (status != EGADS_SUCCESS) std::cout << " Error: EG_localToGlobal" << j + 1 << "/" << tris[3 * k    ] << " = " << status << std::endl;
				status = EG_localToGlobal(tess, j + 1, tris[3 * k + 1], &tin[1]);
				if (status != EGADS_SUCCESS) std::cout << " Error: EG_localToGlobal" << j + 1 << "/" << tris[3 * k + 1] << " = " << status << std::endl;
				status = EG_localToGlobal(tess, j + 1, tris[3 * k + 2], &tin[2]);
				if (status != EGADS_SUCCESS) std::cout << " Error: EG_localToGlobal" << j + 1 << "/" << tris[3 * k + 2] << " = " << status << std::endl;
				connectivityList[connectivityListId].Assign(tin[0]-1, tin[1]-1, tin[2]-1); // ID starts from 0
				++connectivityListId;
			}
		}
		/* ...Component list*/ //not needed
		//for (j = 0; j < ntriang; j++) fprintf(fp, "%6d\n", 1);


		if (solid != bodies[i]) EG_deleteObject(solid);
	}

	status = EG_deleteObject(tess);
	if (status != EGADS_SUCCESS) std::cout << " EG_deleteObject tess  = " << status << std::endl;

	status = EG_deleteObject(model);
	if (status != EGADS_SUCCESS) std::cout << " EG_deleteObject model  = " << status << std::endl;
	EG_close(context);



	//---------------------------------------------------------
	//Exporting in .obj
	//---------------------------------------------------------

	filename = "../output/egads_tess.obj";
	fp.open(filename, std::ios::out);
	std::cout << "Writing Cart3D component OBJ file " << filename << std::endl;
	for (auto it = vertexList.begin(); it != vertexList.end(); ++it)
	{
		fp << "v " << (*it).x << " " << (*it).y << " " << (*it).z << std::endl;
	}
	for (auto it = connectivityList.begin(); it != connectivityList.end(); ++it)
	{
		fp << "f " << (*it).id_1 + 1 << " " << (*it).id_2 + 1 << " " << (*it).id_3 + 1 << std::endl;
	}
	fp.close();

	//---------------------------------------------------------
	//Exporting in .stl
	//---------------------------------------------------------
	filename = "../output/egads_tess.stl";
	fp.open(filename, std::ios::out);
	std::cout << "Writing Cart3D component STL file " << filename << std::endl;

	fp << "solid test" << std::endl;
	for (auto it = connectivityList.begin(); it != connectivityList.end(); ++it)
	{
		auto v1 = &vertexList[(*it).id_1];
		auto v2 = &vertexList[(*it).id_2];
		auto v3 = &vertexList[(*it).id_3];

		auto normal = GetNormalUnit(v1, v2, v3);

		fp << "facet normal " << normal.x << " " << normal.y << " " << normal.z << std::endl;
		fp << "    outer loop" << std::endl;
		fp << "        vertex " << v1->x << " " << v1->y << " " << v1->z << std::endl;
		fp << "        vertex " << v2->x << " " << v2->y << " " << v2->z << std::endl;
		fp << "        vertex " << v3->x << " " << v3->y << " " << v3->z << std::endl;
		fp << "    endloop" << std::endl;
		fp << "endfacet" << std::endl;
	}
	fp << "endsolid test";
	fp.close();

	return 0;
}
